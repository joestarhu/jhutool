from .database import Base
from datetime import datetime
from sqlalchemy import Column,String,Integer,DateTime,ForeignKey,UniqueConstraint
from sqlalchemy.orm import relationship, backref

class Design(Base):
    """产品设计表
    """
    __tablename__ = 'design'

    id = Column(Integer,primary_key=True,comment='ID记录')
    name = Column(String(64), nullable=False, unique=True, comment='产品设计名称')
    axure = Column(String(256), nullable=False, default='', comment='Axure路径')
    sketch = Column(String(256), nullable=False, default='', comment='sketch路径')
    create_time = Column(DateTime,default=datetime.now,comment='创建时间')
