from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import config
from app.api import router
from fastapi.staticfiles import StaticFiles
import os


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins = config.ALLOW_ORIGINS,
    allow_headers = config.ALLOW_HEADERS,
    allow_methods = config.ALLOW_METHODS
)


config.STATIC_BASEDIR = os.path.dirname(os.path.abspath(__file__)) + '/../static'
app.mount("/static", StaticFiles(directory='static'),name='static')
app.mount("/html", StaticFiles(directory='templates'),name='html')
# app.mount("/index", StaticFiles(directory='templates'),name='html')
app.include_router(router)


# from starlette.templating import Jinja2Templates
# from starlette.requests import Request
#
# templates = Jinja2Templates(directory='templates')
#
#
# app.get('/')
# async def home(req: Request):
#     return templates.TemplateResponse('main.html', {'request': req})
