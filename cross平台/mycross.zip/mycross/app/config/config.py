import os

class Config:
    BASEDIR = '/'

    DATABASE_URI = 'sqlite:///cross.db'

    ALLOW_ORIGINS=['*']
    ALLOW_HEADERS=['*']
    ALLOW_METHODS=['*']

config = Config()
