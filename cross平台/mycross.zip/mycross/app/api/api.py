from fastapi import APIRouter
from . import design

router = APIRouter()

router.include_router(design.router,prefix='/design',tags=['设计管理'])
