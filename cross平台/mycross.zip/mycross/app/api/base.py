from pydantic import BaseModel

class SchemaRspBase(BaseModel):
    code:int = 0
    msg:str = 'Succeed'
