from app.db import SessionLocal

def get_db():
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()
