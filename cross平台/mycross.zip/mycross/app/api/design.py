from .deps import get_db
from .base import SchemaRspBase
from fastapi import  APIRouter,Depends,Query,File,Form
from typing import Optional,List
from pydantic import BaseModel
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.db.model import Design
from app.config import config

from enum import Enum

import os

router = APIRouter()

class DesignCreate(BaseModel):
    name:str
    axure:Optional[str] = None
    sketch:Optional[str] = None

class DesignUpdate(DesignCreate):
    id:int

class DesignInfo(DesignUpdate):
    create_time:Optional[datetime] = None

    class Config:
        orm_mode = True

class DesignList(SchemaRspBase):
    total:int = 0
    data:List[DesignInfo] = []

class DesignUpload(SchemaRspBase):
    path:str = ''


class UploadType(str,Enum):
    AXURE='/axure'
    SKETCH='/sketch'


def design_upload(upload_type:UploadType,s:Session,file:bytes,id:int):
    rsp = DesignUpload()
    uploadpath = config.STATIC_BASEDIR + upload_type
    dirname  = uploadpath + f'/{id}'
    filename = dirname+'/uploadDesign.zip'

    try:
        row = s.query(Design).filter(Design.id == id).first()
    except Exception as e:
        rsp.code = -1
        rsp.msg = f'{e}'
        return rsp

    if not row:
        rsp.code = -1
        rsp.msg = '没有产品记录,无法上传'
        return rsp

    if not os.path.exists(dirname):
        try:
            os.mkdir(dirname)
        except  Exception as e:
            rsp.code=-1
            rsp.msg = '上传失败,系统错误,无法创建文件夹'
            return rsp

    try:
        with open(filename,'wb') as f:
            f.write(file)
    except Exception as e:
        rsp.code=-1
        rsp.msg = f'上传失败,系统错误,无法创建文件'
        return rsp

    # 通过时间来确定文件夹名字的唯一性
    dirname = dirname +'/'+ datetime.now().strftime('%y%m%d%H%M%S')
    try:
        cmd = f'unzip -o -d {dirname} {filename}'
        os.system(cmd)
        if upload_type == UploadType.SKETCH:
            cmd = f'mv {filename} {dirname}/download.zip'
            os.system(cmd)

        cmd = f'rm -fr {filename}'
        os.system(cmd)
    except Exception as e :
        rsp.code=-1
        rsp.msg = f'解压失败,无法解压文件'
        return rsp

    if upload_type == UploadType.AXURE:
        start = 'start.html'
    else:
        start = 'index.html'

    #找到start.html
    #os.walk方法 a:路径 b:文件夹 c:文件
    startpath = [a for a,b,c in os.walk(dirname) if start in c]
    if startpath:
        rsp.path = startpath[0][len(config.STATIC_BASEDIR):] + '/' + start
    else:
        rsp.code = -1
        rsp.msg = f'你上传的文件夹中没有{start}文件,无法生成路径'
        cmd = f'rm -fr {dirname}'
        os.system(cmd)
        return rsp

    if upload_type == UploadType.AXURE:
        row.axure = rsp.path
    else:
        row.sketch = rsp.path

    try:
        s.add(row)
        s.commit()
    except Exception as e:
        rsp.code = -1
        rsp.msg = f'{e}'
        return rsp

    return rsp


@router.get('/download/sketch')
async def sketch_download(*,s=Depends(get_db),id:int,path:str):
    begin = len(f'/sketch/{id}')
    file = path[begin:begin+13] + '/download.zip'
    download = f'/sketch/{id}' + file
    return download



@router.post('/upload/sketch',response_model=DesignUpload)
async def sketch_upload(*,s=Depends(get_db),file:bytes=File(...),id:int=Form(...)):
    return design_upload(UploadType.SKETCH,s, file,id)


@router.post('/upload/axure',response_model=DesignUpload)
async def axure_upload(*,s=Depends(get_db),file:bytes=File(...),id:int=Form(...)):
    return design_upload(UploadType.AXURE,s, file,id)


@router.post('/',response_model=SchemaRspBase)
async def create(*,s=Depends(get_db),obj:DesignCreate):
    rsp = SchemaRspBase()
    row = Design(**obj.dict())
    try:
        s.add(row)
        s.commit()
    except IntegrityError as e:
        rsp.code = 100
        rsp.msg = f'{e}'
    except Exception as e:
        rsp.code = -1
        rsp.msg = f'{e}'
    return rsp

@router.get('/',response_model=DesignList)
async def read(*,s=Depends(get_db),idx:int=Query(1,ge=1),size:int=Query(10,ge=0),name:str=None):
    rsp = DesignList()
    skip = (idx-1)*size
    try:
        info = s.query(Design)
        if name:
            info = info.filter(Design.name.like(f'%{name}%'))
        info = info.order_by(Design.create_time.desc())
        rsp.total = info.count()
        rsp.data = info.offset(skip).limit(size).all()
    except Exception as e:
        rsp.code = -1
        rsp.msg = f'{e}'

    return rsp

@router.delete('/{id}',response_model=SchemaRspBase)
async def delete(*,s=Depends(get_db),id:int):
    rsp = SchemaRspBase()
    axurepath = config.STATIC_BASEDIR + '/axure'
    sketchpath = config.STATIC_BASEDIR + '/sketch'

    try:
        row = s.query(Design).filter(Design.id == id).first()
        if row:
            s.delete(row)
            s.commit()
            # 删除无用的文件和文件夹
            path = axurepath+'/'+str(row.id)
            os.system(f'rm -fr {path}')
            path = sketchpath+'/'+str(row.id)
            os.system(f'rm -fr {path}')
    except Exception as e :
        rsp.code = -1
        rsp.msg = f'{e}'
    return rsp
